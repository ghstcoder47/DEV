package de.dsvgruppe.zimdbmsk.gui.marktschwankung.repository;

import de.dsvgruppe.zimdbmsk.gui.marktschwankung.entity.Marktschwankung;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.Collection;
import java.util.List;

@Validated
public interface MarktschwankungRepository extends MongoRepository<Marktschwankung, String> {

    /**
     * Findet alle Marktschwankungen nach Postleitzahlen.
     *
     * @param postleitzahlen Postleitzahlen
     * @return alle Marktschwankungen nach Postleitzahlen
     */
    List<Marktschwankung> findAllByPostleitzahlIn(@NotNull @NotEmpty Collection<@NotNull @NotEmpty String> postleitzahlen);

}
