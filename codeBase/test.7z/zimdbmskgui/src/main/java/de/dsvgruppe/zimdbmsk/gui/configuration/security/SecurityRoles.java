package de.dsvgruppe.zimdbmsk.gui.configuration.security;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.keycloak.adapters.springsecurity.account.KeycloakRole;
import org.springframework.security.core.GrantedAuthority;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class SecurityRoles {
    public static final GrantedAuthority ROLE_ADMIN = new KeycloakRole("ROLE_ADMIN");
    public static final GrantedAuthority ROLE_USER = new KeycloakRole("ROLE_USER");
}
