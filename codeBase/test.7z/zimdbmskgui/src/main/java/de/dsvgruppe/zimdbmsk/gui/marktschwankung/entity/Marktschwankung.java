package de.dsvgruppe.zimdbmsk.gui.marktschwankung.entity;

import lombok.Builder;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Builder
@Document
public class Marktschwankung {

    @Id
    private String id;

    private int objektart;
    private String postleitzahl;

    private double ueber1Jahr;
    private double ueber2Jahre;
    private double ueber3Jahre;

    private String ueber1JahrInfos;
    private String ueber2JahreInfos;
    private String ueber3JahreInfos;

    private boolean schwankungAufgetreteten;

}
