package de.dsvgruppe.zimdbmsk.gui.configuration.security;

import org.keycloak.adapters.springboot.KeycloakSpringBootConfigResolver;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GUISecurityConfiguration {

    /*
     * Bean has to be in a separate class because
     * inside of SecurityConfiguration it creates a circular dependency
     */
    @Bean
    public KeycloakSpringBootConfigResolver keyCloakConfigResolver() {
        return new KeycloakSpringBootConfigResolver();
    }

}
