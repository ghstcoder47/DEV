package de.dsvgruppe.zimdbmsk.gui.architecture;

import com.tngtech.archunit.junit.AnalyzeClasses;
import com.tngtech.archunit.junit.ArchTest;
import com.tngtech.archunit.lang.ArchRule;
import org.springframework.data.mongodb.core.mapping.Document;

import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.classes;
import static de.dsvgruppe.zimdbmsk.gui.architecture.ArchitectureTestConstants.BASE_PACKAGE;

@AnalyzeClasses(packages = BASE_PACKAGE)
public class DocumentArchitectureTest {

    @ArchTest
    public static final ArchRule entity_package = classes().that()
            .areAnnotatedWith(Document.class)
            .should().resideInAPackage("..entity..")
            .because("all entities must be in a 'entity' package");

}
