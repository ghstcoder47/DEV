package de.dsvgruppe.zimdbmsk.gui.test;

public class TestConstants {

    public final static String INTEGRATION_TEST = "integration-test";

    private TestConstants() {
        throw new IllegalStateException("utility constructor");
    }

}
