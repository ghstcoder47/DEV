package de.dsvgruppe.zimdbmsk.gui.architecture;

import com.tngtech.archunit.junit.AnalyzeClasses;
import com.tngtech.archunit.junit.ArchTest;
import com.tngtech.archunit.lang.ArchRule;

import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.classes;
import static de.dsvgruppe.zimdbmsk.gui.architecture.ArchitectureTestConstants.BASE_PACKAGE;

@AnalyzeClasses(packages = BASE_PACKAGE, importOptions = CustomImportOptions.DontIncludeArchitectureClasses.class)
public class RepositoryArchitectureTest {

    @ArchTest
    public static final ArchRule repository_package = classes().that()
            .haveNameMatching(".*Repository")
            .should().resideInAPackage("..repository..")
            .because("all repositories must be in a 'repository' package");

}
