package de.dsvgruppe.zimdbmsk.gui.marktschwankung.boundary;

import de.dsvgruppe.zimdbmsk.gui.marktschwankung.entity.Marktschwankung;
import de.dsvgruppe.zimdbmsk.gui.marktschwankung.entity.MarktschwankungTestFixture;
import de.dsvgruppe.zimdbmsk.gui.marktschwankung.repository.MarktschwankungRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anyCollection;
import static org.mockito.BDDMockito.given;

class MarktschwankungBoundaryTest {

    @Mock
    MarktschwankungRepository repository;

    @InjectMocks
    MarktschwankungBoundary boundary;

    @BeforeEach
    public void initMocks() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void search() {

        /* given */
        List<Marktschwankung> marktschwankungs = new ArrayList<>();
        Marktschwankung marktschwankung1 = MarktschwankungTestFixture.marktschwankung_12345_1();
        marktschwankungs.add(marktschwankung1);

        given(repository.findAllByPostleitzahlIn(anyCollection())).willReturn(marktschwankungs);

        /* when */
        Collection<String> postleitzahlen = new HashSet<>();
        postleitzahlen.add("12345");
        List<Marktschwankung> found = boundary.search(postleitzahlen);

        /* then */
        assertThat(found).hasSize(1);
        assertThat(found).containsOnly(marktschwankung1);
    }
}