package de.dsvgruppe.zimdbmsk.gui.architecture;

public class ArchitectureTestConstants {

    public final static String BASE_PACKAGE = "de.dsvgruppe.zimdbmsk.gui";
    public final static String BASE_PACKAGE_LOCATION = "de/dsvgruppe/zimdbmsk/gui";

}
