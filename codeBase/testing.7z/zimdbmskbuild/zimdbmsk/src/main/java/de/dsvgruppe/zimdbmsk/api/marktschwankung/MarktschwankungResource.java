package de.dsvgruppe.zimdbmsk.api.marktschwankung;

import de.dsvgruppe.zimdbmsk.gui.marktschwankung.entity.Marktschwankung;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/marktschwankung")
public class MarktschwankungResource {

    @Autowired
    MarktschwankungController marktschwankungController;

    @PostMapping
    public ResponseEntity<List<Marktschwankung>> search(@RequestBody(required = true) PostleitzahlenRequestBody postleitzahlenRequestBody) {
        return marktschwankungController.search(postleitzahlenRequestBody);
    }



    /* nur zum ausprobieren */
    @GetMapping
    public String getHallo() {
        return "hallo";
    }

    @GetMapping("/{plz}")
    public String getHalloWithPlz(@PathVariable("plz") String plz) {
        return "Hallo mit " + plz;
    }
    /* nur zum ausprobieren */

}
