package de.dsvgruppe.zimdbmsk.gui;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZimdbmskApplication {

    public static void main(String[] args) {
        SpringApplication.run(ZimdbmskApplication.class, args);
    }

}
