package de.dsvgruppe.zimdbmsk.gui.configuration.security;

import org.springframework.security.core.Authentication;

public interface KeycloakAuthenticationTokenExtendedAttributes extends Authentication {
    String getUsername();

    Long getZbvUserId();

    String getSalutation();

    Long getOrganisationId();

    String getEmailAddress();

    String getOrganisationCustomerNumber();

    String getOrganisationName();
}
