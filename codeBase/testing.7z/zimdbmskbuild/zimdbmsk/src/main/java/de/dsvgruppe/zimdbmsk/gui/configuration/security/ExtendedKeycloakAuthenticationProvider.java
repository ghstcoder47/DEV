package de.dsvgruppe.zimdbmsk.gui.configuration.security;

import org.keycloak.adapters.springsecurity.authentication.KeycloakAuthenticationProvider;
import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
import org.springframework.security.core.Authentication;

public class ExtendedKeycloakAuthenticationProvider extends KeycloakAuthenticationProvider {
    @Override
    public Authentication authenticate(Authentication authentication) {
        KeycloakAuthenticationToken token = (KeycloakAuthenticationToken) super.authenticate(authentication);
        return new ExtendedKeycloakAuthenticationToken(token.getAccount(), token.isInteractive(), token.getAuthorities());
    }
}
