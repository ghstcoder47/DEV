package de.dsvgruppe.zimdbmsk.gui.architecture;

import org.springframework.stereotype.Component;

import java.lang.annotation.*;

/**
 * Control stereotype.
 */
@Component
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface Control {
}
