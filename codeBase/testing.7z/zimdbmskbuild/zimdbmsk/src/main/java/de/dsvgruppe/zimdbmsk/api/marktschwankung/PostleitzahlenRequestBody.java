package de.dsvgruppe.zimdbmsk.api.marktschwankung;

import lombok.Builder;
import lombok.Data;

import java.util.Collection;

@Data
@Builder
public class PostleitzahlenRequestBody {

    Collection<String> postleitzahlen;
}
