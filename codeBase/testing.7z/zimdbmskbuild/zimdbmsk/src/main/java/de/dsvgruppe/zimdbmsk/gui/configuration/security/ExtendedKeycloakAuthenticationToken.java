package de.dsvgruppe.zimdbmsk.gui.configuration.security;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import org.keycloak.adapters.OidcKeycloakAccount;
import org.keycloak.adapters.spi.KeycloakAccount;
import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;

import java.util.Collection;
import java.util.Map;

@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ExtendedKeycloakAuthenticationToken extends KeycloakAuthenticationToken implements KeycloakAuthenticationTokenExtendedAttributes {

    private static final long serialVersionUID = -2826227205797377357L;

    private String username;
    private Long zbvUserId;
    private String salutation;
    private Long organisationId;
    private String emailAddress;
    private String organisationCustomerNumber;
    private String organisationName;

    /**
     * Creates unauthenticated token
     */
    public ExtendedKeycloakAuthenticationToken(KeycloakAccount account, boolean interactive) {
        super(account, interactive);
    }

    /**
     * Creates authenticated token
     */
    public ExtendedKeycloakAuthenticationToken(KeycloakAccount account, boolean interactive, Collection<? extends GrantedAuthority> authorities) {
        super(account, interactive, authorities);

        OidcKeycloakAccount oidcKeycloakAccount = (OidcKeycloakAccount) account;
        setUsername(oidcKeycloakAccount.getKeycloakSecurityContext().getIdToken().getPreferredUsername());
        Map<String, Object> claims = oidcKeycloakAccount.getKeycloakSecurityContext().getIdToken().getOtherClaims();
        setZbvUserId(Long.valueOf((String) claims.get("zbvUserId")));
        setSalutation((String) claims.get("salutation"));
        setOrganisationId(Long.valueOf((String) claims.get("organisationId")));
        setEmailAddress((String) claims.get("emailAddress"));
        setOrganisationCustomerNumber((String) claims.get("organisationCustomerNumber"));
        setOrganisationName((String) claims.get("organisationName"));
    }
}
