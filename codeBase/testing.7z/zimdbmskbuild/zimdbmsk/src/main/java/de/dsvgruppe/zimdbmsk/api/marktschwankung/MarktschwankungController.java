package de.dsvgruppe.zimdbmsk.api.marktschwankung;

import de.dsvgruppe.zimdbmsk.gui.marktschwankung.boundary.MarktschwankungBoundary;
import de.dsvgruppe.zimdbmsk.gui.marktschwankung.entity.Marktschwankung;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;

@Component
public class MarktschwankungController {

    @Autowired
    MarktschwankungBoundary marktschwankungBoundary;

    public ResponseEntity<List<Marktschwankung>> search(PostleitzahlenRequestBody postleitzahlenRequestBody) {

        List<Marktschwankung> marktschwankungen = marktschwankungBoundary.search(postleitzahlenRequestBody.getPostleitzahlen());
        ResponseEntity<List<Marktschwankung>> responseEntity;

        if (Objects.isNull(marktschwankungen) || marktschwankungen.isEmpty()) {
            responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else {
            responseEntity = new ResponseEntity<>(marktschwankungen, HttpStatus.OK);
        }

        return responseEntity;
    }
}
