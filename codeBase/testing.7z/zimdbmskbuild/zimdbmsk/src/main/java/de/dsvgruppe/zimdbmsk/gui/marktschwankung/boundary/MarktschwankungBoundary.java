package de.dsvgruppe.zimdbmsk.gui.marktschwankung.boundary;

import de.dsvgruppe.zimdbmsk.gui.architecture.Boundary;
import de.dsvgruppe.zimdbmsk.gui.marktschwankung.entity.Marktschwankung;
import de.dsvgruppe.zimdbmsk.gui.marktschwankung.repository.MarktschwankungRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.NotBlank;
import java.util.Collection;
import java.util.List;

@Boundary
@Validated
@RequiredArgsConstructor
@Slf4j
public class MarktschwankungBoundary {

    private MarktschwankungRepository repository;

    /**
     * Findet alle Marktschwankungen nach Postleitzahlen.
     *
     * @param postleitzahlen Postleitzahlen
     * @return alle Marktschwankungen nach Postleitzahlen
     */
    // TODO test, ob diese Systax funktioniert
    //@PreAuthorize("hasAuthority(ZBVAuthority.ROLE_USER.getAuthority())")
    @PreAuthorize("hasAuthority(ROLE_USER)")
    public List<Marktschwankung> search(@NotBlank Collection<@NotBlank String> postleitzahlen) {
        log.info("searching for Marktschwankung with postleitzahlen {}", postleitzahlen);
        List<Marktschwankung> all = repository.findAllByPostleitzahlIn(postleitzahlen);
        log.info("found {} fluctuations", all.size());
        return all;
    }

}
