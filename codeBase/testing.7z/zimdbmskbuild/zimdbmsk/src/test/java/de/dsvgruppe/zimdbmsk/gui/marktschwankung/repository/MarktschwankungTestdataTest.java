package de.dsvgruppe.zimdbmsk.gui.marktschwankung.repository;

import de.dsvgruppe.zimdbmsk.gui.marktschwankung.entity.Marktschwankung;
import de.dsvgruppe.zimdbmsk.gui.marktschwankung.entity.MarktschwankungTestFixture;
import de.dsvgruppe.zimdbmsk.gui.test.TestConstants;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.ArrayList;
import java.util.List;

@SpringBootTest
@ActiveProfiles(TestConstants.INTEGRATION_TEST)
class MarktschwankungTestdataTest {

    @Autowired
    MarktschwankungRepository repository;

    @Test
    @DisplayName("Generate testdata with 99999 PLZs combined with 1-8 objectTypes")
    void insertTestdata() {

        /* remove all exiting data */
        repository.deleteAll();

        int plzLength = 5;
        int startPLZs = 1;
        int maxPLZs = 99999;

        List<Marktschwankung> create = new ArrayList<>(maxPLZs);

        /* generate PLZs */
        for (int i = startPLZs; i <= maxPLZs; i++) {
            String plz = StringUtils.leftPad(Integer.toString(i), plzLength, '0');

            /* generate objectTypes */
            int startObjectTypes = 1;
            int maxObjectType = 8;
            for (int objectType = startObjectTypes; objectType <= maxObjectType; objectType++) {
                create.add(MarktschwankungTestFixture.marktschwankung(plz, objectType));
            }
        }

        /* save all */
        repository.saveAll(create);
    }

}