package de.dsvgruppe.zimdbmsk.gui.architecture;

import com.tngtech.archunit.junit.AnalyzeClasses;
import com.tngtech.archunit.junit.ArchTest;
import com.tngtech.archunit.lang.ArchRule;

import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.classes;
import static de.dsvgruppe.zimdbmsk.gui.architecture.ArchitectureTestConstants.BASE_PACKAGE;

@AnalyzeClasses(packages = BASE_PACKAGE, importOptions = CustomImportOptions.DontIncludeArchitectureClasses.class)
public class BoundaryArchitectureTest {

    // @formatter:off
    @ArchTest
    public static final ArchRule boundary_package = classes().that()
            .areAnnotatedWith(Boundary.class)
            .or().haveNameMatching(".*Boundary")
            .should().resideInAPackage("..boundary..")
            .because("all boundaries must be in a 'boundary' package");

    @ArchTest
    public static final ArchRule boundary_suffix = classes().that()
            .areAnnotatedWith(Boundary.class)
            .should().haveNameMatching(".*Boundary")
            .because("all boundaries must be in named '*Boundary'");

    @ArchTest
    public static final ArchRule boundary_annotation = classes().that()
            .haveNameMatching(".*Boundary")
            .should().beAnnotatedWith(Boundary.class)
            .because("all boundaries must be annotated with '@Boundary'");
    // @formatter:on
}