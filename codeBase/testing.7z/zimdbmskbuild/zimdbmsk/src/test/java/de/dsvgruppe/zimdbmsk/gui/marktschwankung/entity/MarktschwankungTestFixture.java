package de.dsvgruppe.zimdbmsk.gui.marktschwankung.entity;

public class MarktschwankungTestFixture {

    public static Marktschwankung marktschwankung_12345_1() {
        return marktschwankung("12345", 1);
    }

    public static Marktschwankung marktschwankung_12345_2() {
        return marktschwankung("12345", 2);
    }

    public static Marktschwankung marktschwankung_54321_1() {
        return marktschwankung("54321", 1);
    }

    public static Marktschwankung marktschwankung(String postCode, int objectType) {
        return Marktschwankung.builder()
                .objektart(objectType)
                .postleitzahl(postCode)
                .ueber1Jahr(objectType + 0.1)
                .ueber1JahrInfos("1")
                .ueber2Jahre(objectType + 0.2)
                .ueber2JahreInfos("2")
                .ueber3Jahre(objectType + 0.3)
                .ueber3JahreInfos("3")
                .schwankungAufgetreteten(false)
                .build();
    }

}
