package de.dsvgruppe.zimdbmsk.gui;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZimdbmskApplicationTests {

    @Test
    void contextLoads() {
    }

}
