package de.dsvgruppe.zimdbmsk.gui.architecture;

import com.tngtech.archunit.junit.AnalyzeClasses;
import com.tngtech.archunit.junit.ArchTest;
import com.tngtech.archunit.lang.ArchRule;
import org.springframework.security.access.prepost.PreAuthorize;

import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.methods;
import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.noMethods;
import static de.dsvgruppe.zimdbmsk.gui.architecture.ArchitectureTestConstants.BASE_PACKAGE;

@AnalyzeClasses(packages = BASE_PACKAGE, importOptions = CustomImportOptions.DontIncludeArchitectureClasses.class)
public class SecurityAnnotationsArchitectureTest {

    @ArchTest
    public static final ArchRule method_security_is_set = methods().that()
            .areDeclaredInClassesThat().areAnnotatedWith(Boundary.class)
            .or().areDeclaredInClassesThat().haveNameMatching(".*Boundary")
            .and().arePublic()
            .should()
            .beAnnotatedWith(PreAuthorize.class)
            .because("all public boundary methods must be annotated with @PreAuthorize");

    @ArchTest
    public static final ArchRule method_security_only_for_boundaries = noMethods().that()
            .areDeclaredInClassesThat().areNotAnnotatedWith(Boundary.class)
            .or().areDeclaredInClassesThat().haveNameNotMatching(".*Boundary")
            .should()
            .beAnnotatedWith(PreAuthorize.class)
            .because("only boundary methods should define method security with @PreAuhorize");


}
