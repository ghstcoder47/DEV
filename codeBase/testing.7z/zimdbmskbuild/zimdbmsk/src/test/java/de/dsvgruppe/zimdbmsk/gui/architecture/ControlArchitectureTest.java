package de.dsvgruppe.zimdbmsk.gui.architecture;

import com.tngtech.archunit.junit.AnalyzeClasses;
import com.tngtech.archunit.junit.ArchTest;
import com.tngtech.archunit.lang.ArchRule;

import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.classes;
import static de.dsvgruppe.zimdbmsk.gui.architecture.ArchitectureTestConstants.BASE_PACKAGE;

@AnalyzeClasses(packages = BASE_PACKAGE, importOptions = CustomImportOptions.DontIncludeArchitectureClasses.class)
public class ControlArchitectureTest {

    @ArchTest
    public static final ArchRule control_package = classes().that()
            .areAnnotatedWith(Control.class)
            .or().haveNameMatching(".*Control")
            .should().resideInAPackage("..controller..")
            .because("all controls must be in a 'control' package");

    @ArchTest
    public static final ArchRule control_annotation = classes().that()
            .haveNameMatching(".*Control")
            .should().beAnnotatedWith(Control.class)
            .because("all controls must be annotated with '@Control'");

}
