package de.dsvgruppe.zimdbmsk.gui.marktschwankung.repository;

import de.dsvgruppe.zimdbmsk.gui.marktschwankung.entity.Marktschwankung;
import de.dsvgruppe.zimdbmsk.gui.marktschwankung.entity.MarktschwankungTestFixture;
import de.dsvgruppe.zimdbmsk.gui.test.TestConstants;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ActiveProfiles;

import javax.validation.ConstraintViolationException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

@SpringBootTest
@ActiveProfiles(TestConstants.INTEGRATION_TEST)
@Rollback
class MarktschwankungRepositoryTest {

    @Autowired
    MarktschwankungRepository repository;

    @Test
    void findAll() {
        /* given */
        repository.deleteAll();
        Marktschwankung marktschwankung1 = repository.save(MarktschwankungTestFixture.marktschwankung_12345_1());

        /* when */
        List<Marktschwankung> all = repository.findAll();

        /* then */
        assertThat(all).hasSize(1);
        assertThat(all).containsExactly(marktschwankung1);
    }


    @Test
    void findAllByPostCodeIn() {
        /* given */
        repository.deleteAll();
        Marktschwankung marktschwankung1 = repository.save(MarktschwankungTestFixture.marktschwankung_12345_1());
        Marktschwankung marktschwankung2 = repository.save(MarktschwankungTestFixture.marktschwankung_12345_2());
        Marktschwankung marktschwankung3 = repository.save(MarktschwankungTestFixture.marktschwankung_54321_1());

        /* when */
        Set<String> postleitzahlen = new HashSet<>();
        postleitzahlen.add("12345");

        List<Marktschwankung> all = repository.findAllByPostleitzahlIn(postleitzahlen);

        /* then */
        assertThat(all).hasSize(2);
        assertThat(all).containsOnly(marktschwankung1, marktschwankung2);
    }

    @Test
    void findAllByPostCodeIn_null_postcodes_collection() {
        assertThrows(ConstraintViolationException.class, () -> {
            repository.findAllByPostleitzahlIn(null);
        });
    }

    @Test
    void findAllByPostCodeIn_empty_postcodes_collection() {
        assertThrows(ConstraintViolationException.class, () -> {
            repository.findAllByPostleitzahlIn(new HashSet<>());
        });
    }

    @Test
    void findAllByPostCodeIn_postcodes_has_a_null_item() {
        assertThrows(ConstraintViolationException.class, () -> {
            Set<String> postCodes = new HashSet<>();
            postCodes.add(null);
            repository.findAllByPostleitzahlIn(postCodes);
        });
    }

    @Test
    void findAllByPostCodeIn_postcodes_has_empty_item() {
        assertThrows(ConstraintViolationException.class, () -> {
            Set<String> postCodes = new HashSet<>();
            postCodes.add("");
            repository.findAllByPostleitzahlIn(postCodes);
        });
    }

}