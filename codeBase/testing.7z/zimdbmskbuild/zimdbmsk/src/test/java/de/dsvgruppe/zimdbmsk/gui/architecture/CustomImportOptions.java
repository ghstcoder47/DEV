package de.dsvgruppe.zimdbmsk.gui.architecture;

import com.tngtech.archunit.core.importer.ImportOption;
import com.tngtech.archunit.core.importer.Location;

import static de.dsvgruppe.zimdbmsk.gui.architecture.ArchitectureTestConstants.BASE_PACKAGE_LOCATION;

public class CustomImportOptions {

    /**
     * NOTE: This excludes all class contain "Test", so don't use this, if you have a package test that you want to
     * import.
     */
    public static final class DontIncludeTests implements ImportOption {
        @Override
        public boolean includes(final Location location) {
            return !location.contains("Test");
        }
    }

    /**
     * This excludes all classes contained in the architecture package location.
     */
    public static final class DontIncludeArchitectureClasses implements ImportOption {
        @Override
        public boolean includes(final Location location) {
            return !location.contains(BASE_PACKAGE_LOCATION + "/architecture");
        }
    }

}
