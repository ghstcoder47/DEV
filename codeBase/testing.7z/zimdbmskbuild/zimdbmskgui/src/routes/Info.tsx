import React from "react";

export const Info = () => {
    return <div></div>;
};
