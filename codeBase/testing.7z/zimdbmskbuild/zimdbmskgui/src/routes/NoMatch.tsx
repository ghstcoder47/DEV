import React from "react";

export const NoMatch = () => <h1>404</h1>;
