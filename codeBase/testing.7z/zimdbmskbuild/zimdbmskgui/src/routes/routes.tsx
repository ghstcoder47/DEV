import React from "react";
import { RouteProps, Redirect } from "react-router-dom";
import { Abfragen } from "./Abfragen";
import { Info } from "./Info";
import { NoMatch } from "./NoMatch";

export const ROUTE_INDEX = "/";
export const ROUTE_ABFRAGEN = "/abfragen";
export const ROUTE_INFO = "/info";
export const ROUTE_NOMATCH = "*";

interface ExtendedRouteProps extends RouteProps {
    title: string;
}

export const routes: ExtendedRouteProps[] = [
    {
        path: ROUTE_INDEX,
        exact: true,
        component: () => <Redirect to={{ pathname: "/abfragen" }} />,
        title: "Marktschwankungskonzept"
    },
    {
        path: ROUTE_ABFRAGEN,
        exact: true,
        component: Abfragen,
        title: "Abfragen"
    },
    {
        path: ROUTE_INFO,
        exact: true,
        component: Info,
        title: "Info"
    },
    {
        path: ROUTE_NOMATCH,
        exact: false,
        component: NoMatch,
        title: "Fehler"
    }
];
