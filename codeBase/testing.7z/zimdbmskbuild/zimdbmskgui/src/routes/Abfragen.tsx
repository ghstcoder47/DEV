import React, { useState } from "react";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Card from "react-bootstrap/Card";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import ReactTagInput from "@pathofdev/react-tag-input";
import { FileInput } from "../components/FileInput";

export const Abfragen = () => {
    return (
        <Container>
            <Row>
                <Col>
                    <AbfragenCard />
                </Col>
            </Row>
            <br />
            <Form>
                <Row>
                    <Col md="6">
                        <Row>
                            <FormPLZSearch />
                        </Row>
                    </Col>
                    <Col md="6">
                        <Row>
                            <FormPLZFileUpload />
                        </Row>
                    </Col>
                </Row>
            </Form>
            <br />
            <Row>
                <Col>
                    <MeineDateienCard />
                </Col>
            </Row>
        </Container>
    );
};

const FormPLZSearch = () => {
    const [tags, setTags] = useState<string[]>([]);
    return (
        <>
            <Col md="8">
                <Form.Label>Einzelne PLZ abfragen (max. 10 PLZ)</Form.Label>
                <ReactTagInput
                    tags={tags}
                    onChange={setTags}
                    placeholder="PLZ eingeben und Eingabe drücken"
                    maxTags={10}
                />
            </Col>
            <Col className="align-self-end">
                {/* // TODO align-self-end moves the button to the bottom but you need to remove the Form.Group... */}
                <Button variant="primary" type="submit" block>
                    Abfragen&nbsp;
                    <span className="dsv-icon dsv-icon-arrow-right" />
                </Button>
            </Col>
        </>
    );
};

const FormPLZFileUpload = () => {
    const [file, setFile] = useState<string | undefined>();
    return (
        <>
            <Col md="8">
                <FileInput file={file} onChange={setFile} />
            </Col>
            <Col className="align-self-end">
                <Button variant="primary" type="submit" block>
                    Abfragen&nbsp;
                    <span className="dsv-icon dsv-icon-arrow-right" />
                </Button>
            </Col>
        </>
    );
};

const AbfragenCard = () => {
    return (
        <Card>
            <Card.Body>
                <Card.Title as="h2">Abfragen</Card.Title>
                <Card.Text>
                    Für die Abfrage von Daten aus dem Immobilienmarktmonitoring
                    bestehen 2 Möglichkeiten:
                </Card.Text>
                <Card.Text as="div">
                    <ol>
                        <li>
                            eine manuelle PLZ-Suche für bis zu 10 Postleitzahlen
                            durchzuführen oder
                        </li>
                        <li>
                            eine XLS, XLSX, CSV oder TXT Datei im vorgegebenen
                            Format hochzuladen
                        </li>
                    </ol>
                </Card.Text>
                <Card.Text>
                    Für den Datei-Upload beachten Sie bitte das vorgegebene
                    Datenformat. Erläuterungen zum Dateiaufbau sowie eine
                    Musterdatei finden Sie im Info-Bereich.
                </Card.Text>
            </Card.Body>
        </Card>
    );
};

const MeineDateienCard = () => {
    return (
        <Card>
            <Card.Body>
                <Card.Title as="h2">Meine Dateien</Card.Title>
                <Card.Text>
                    Die fertigen Ergebnisdateien werden unter „Meine Dateien“
                    angezeigt und können herunterzuladen werden. Sie erhalten
                    eine E-Mailbenachrichtigung, wenn die Verarbeitung Ihrer
                    Abfrage abgeschlossen ist und die Ergebnisse zur Verfügung
                    stehen.
                </Card.Text>
                <Card.Text>
                    Die Ergebnisdateien stehen bis zum angegebenen Datum im Feld
                    „Download gültig bis“ zum Herunterladen zur Verfügung. Nach
                    diesem Datum werden die Ergebnis-Dateien gelöscht. Die
                    Urheberrechte an den Zeitreihen liegen und verbleiben bei
                    der vdpResearch GmbH. Die Ergebnisse der Messung stehen
                    ausschließlich dem Institut für die interne Nutzung für
                    Zwecke der Marktüberwachung zur Verfügung. Die Weitergabe
                    der Ergebnisse an Dritte ist ohne schriftliche Zustimmung
                    der vdpResearch nicht gestattet. Von dieser Regelung
                    ausgenommen sind die Bundesanstalt für
                    Finanzdienstleistungsaufsicht (BaFin), die Deutsche
                    Bundesbank, externe Prüfer wie z.B. Verbandsprüfer sowie im
                    Rahmen von § 44 Kreditwesengesetz (KWG) zur Prüfung
                    Berufene.
                </Card.Text>
            </Card.Body>
        </Card>
    );
};
