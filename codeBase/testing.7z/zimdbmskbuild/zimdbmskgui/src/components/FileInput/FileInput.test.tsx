import React from "react";
import { shallow } from "enzyme";
import { FileInput } from "./index";
import FormLabel from "react-bootstrap/FormLabel";

describe("FileInput component", () => {
    it("should render file input with undefined file.", () => {
        const file = undefined;
        const setFile = () => {};

        const wrapper = shallow(<FileInput file={file} onChange={setFile} />);

        expect(wrapper.find(FormLabel).at(0)).toIncludeText(
            "PLZ in Datei abfragen"
        );
        expect(wrapper.find(FormLabel).at(1)).toIncludeText(
            "Keine Datei ausgewählt"
        );
        expect(wrapper).toMatchSnapshot();
    });

    it("should render file input with a given file.", () => {
        const file = "TestFile";
        const setFile = () => {};

        const wrapper = shallow(<FileInput file={file} onChange={setFile} />);

        expect(wrapper.find(FormLabel).at(0)).toIncludeText(
            "PLZ in Datei abfragen"
        );
        expect(wrapper.find(FormLabel).at(1)).toIncludeText("TestFile");
        expect(wrapper).toMatchSnapshot();
    });
    // TODO: test with onChange file
});
