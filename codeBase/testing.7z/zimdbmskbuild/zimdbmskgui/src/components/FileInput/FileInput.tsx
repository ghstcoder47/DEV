import React from "react";
import Form from "react-bootstrap/Form";

interface Props {
    file: string | undefined;
    onChange: (file: string | undefined) => void;
}

const FileInput = ({ file, onChange }: Props) => {
    const setFile = (event: React.ChangeEvent<HTMLInputElement>) => {
        onChange(event.target.files?.item(0)?.name);
    };
    return (
        <>
            <Form.Label>PLZ in Datei abfragen</Form.Label>
            <div className="custom-file">
                <Form.Control
                    type="file"
                    placeholder="Datei"
                    className="custom-file-input"
                    onChange={setFile}
                />
                <Form.Label className="custom-file-label">
                    {file ?? "Keine Datei ausgewählt"}
                </Form.Label>
            </div>
        </>
    );
};

export default FileInput;
