import { createContext, useContext } from "react";

interface SearchState {
    plzs: string[];
}

export const SearchContext = createContext<SearchState>({ plzs: [] });

export const useSearchContext = () => useContext(SearchContext);
