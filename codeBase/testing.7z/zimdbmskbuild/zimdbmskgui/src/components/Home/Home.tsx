import React from "react";
import Card from "react-bootstrap/Card";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import { useSearchContext } from "./context/context";

type Props = {
    title: string;
};

const Home = ({ title }: Props) => {
    const { plzs } = useSearchContext();
    return (
        <>
            <Row>
                <Col>
                    <Card>
                        <Card.Body>
                            <Card.Title>{title}</Card.Title>
                            <Card.Text as="div">
                                <ul>
                                    {plzs.map((plz, i) => (
                                        <li key={i}>{plz}</li>
                                    ))}
                                </ul>
                            </Card.Text>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </>
    );
};

export default Home;
