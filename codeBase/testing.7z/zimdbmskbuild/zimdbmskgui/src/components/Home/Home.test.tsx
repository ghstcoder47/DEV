import React from "react";
import { Home } from "./index";
import { shallow } from "enzyme";
import { useSearchContext } from "./context/context";

jest.mock("./context/context");

describe("Home component", () => {
    const initialState = {
        plzs: ["12345", "54321"]
    };

    afterEach(() => {
        jest.clearAllMocks();
    });

    it("should render, given an initial state.", () => {
        (useSearchContext as jest.Mock).mockReturnValueOnce(initialState);

        const wrapper = shallow(<Home title="Hallo" />);

        expect(wrapper).toIncludeText(initialState.plzs[0]);
    });

    it("should match snapshot, given initial state", () => {
        (useSearchContext as jest.Mock).mockReturnValueOnce(initialState);

        const wrapper = shallow(<Home title="Hallo" />);

        expect(wrapper).toMatchSnapshot();
        expect(useSearchContext).toHaveBeenCalledTimes(1);
    });
});
