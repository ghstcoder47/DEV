import { useLocation } from "react-router-dom";
import { ROUTE_INDEX, ROUTE_ABFRAGEN } from "../../routes/routes";
import { shallow } from "enzyme";
import { Header } from ".";
import React from "react";

jest.mock("react-router-dom", () => ({
    ...jest.requireActual("react-router-dom"),
    useLocation: jest.fn(() => {
        throw new Error("Mock behavior not defined.");
    })
}));

describe("Header component", () => {
    beforeEach(() => {
        document.title = "";
    });

    afterEach(() => {
        jest.clearAllMocks();
    });

    it("should render header and set document title corresponding to given location with route '/'.", () => {
        (useLocation as jest.Mock).mockReturnValueOnce({
            pathname: ROUTE_INDEX
        });

        const wrapper = shallow(<Header />);

        expect(document.title).toEqual("MSK - Marktschwankungskonzept");
        expect(useLocation).toHaveBeenCalledTimes(1);
        expect(wrapper).toMatchSnapshot();
    });

    it("should render header and set document title corresponding to given location with route '/abfragen'.", () => {
        (useLocation as jest.Mock).mockReturnValueOnce({
            pathname: ROUTE_ABFRAGEN
        });

        const wrapper = shallow(<Header />);

        expect(document.title).toEqual("MSK - Abfragen");
        expect(useLocation).toHaveBeenCalledTimes(1);
        expect(wrapper).toMatchSnapshot();
    });
});
