import React from "react";
import { shallow } from "enzyme";
import { Breadcrumb as OwnBreadcrumb } from ".";
import { useLocation } from "react-router-dom";
import {
    ROUTE_INDEX,
    ROUTE_ABFRAGEN,
    ROUTE_INFO,
    ROUTE_NOMATCH
} from "../../../routes/routes";
import Breadcrumb from "react-bootstrap/Breadcrumb";

jest.mock("react-router-dom", () => ({
    ...jest.requireActual("react-router-dom"),
    useLocation: jest.fn(() => {
        throw new Error("Mock behavior not defined.");
    })
}));

describe("Breadcrumd component", () => {
    afterEach(() => {
        jest.clearAllMocks();
    });

    it("should render breadcrumb corresponding to given location with route '/'.", () => {
        (useLocation as jest.Mock).mockReturnValueOnce({
            pathname: ROUTE_INDEX
        });

        const wrapper = shallow(<OwnBreadcrumb />);

        expect(wrapper.find(Breadcrumb.Item).at(2)).toIncludeText(
            "Marktschwankungskonzept"
        );
        expect(useLocation).toHaveBeenCalledTimes(1);
        expect(wrapper).toMatchSnapshot();
    });

    it("should render breadcrumb corresponding to given location with route '/abfragen'.", () => {
        (useLocation as jest.Mock).mockReturnValueOnce({
            pathname: ROUTE_ABFRAGEN
        });

        const wrapper = shallow(<OwnBreadcrumb />);

        expect(wrapper.find(Breadcrumb.Item).at(2)).toIncludeText("Abfragen");
        expect(useLocation).toHaveBeenCalledTimes(1);
        expect(wrapper).toMatchSnapshot();
    });

    it("should render breadcrumb corresponding to given location with route '/info'.", () => {
        (useLocation as jest.Mock).mockReturnValueOnce({
            pathname: ROUTE_INFO
        });

        const wrapper = shallow(<OwnBreadcrumb />);

        expect(wrapper.find(Breadcrumb.Item).at(2)).toIncludeText("Info");
        expect(useLocation).toHaveBeenCalledTimes(1);
        expect(wrapper).toMatchSnapshot();
    });

    it("should render breadcrumb corresponding to given location with route '/fehler'.", () => {
        (useLocation as jest.Mock).mockReturnValueOnce({
            pathname: ROUTE_NOMATCH
        });

        const wrapper = shallow(<OwnBreadcrumb />);

        expect(wrapper.find(Breadcrumb.Item).at(2)).toIncludeText("Fehler");
        expect(useLocation).toHaveBeenCalledTimes(1);
        expect(wrapper).toMatchSnapshot();
    });
});
