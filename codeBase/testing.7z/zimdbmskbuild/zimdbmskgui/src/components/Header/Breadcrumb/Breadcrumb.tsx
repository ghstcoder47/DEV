import React from "react";
import Container from "react-bootstrap/Container";
import { default as BootstrapBreadcrumb } from "react-bootstrap/Breadcrumb";
import { LinkContainer } from "react-router-bootstrap";
import { ROUTE_INDEX, routes, ROUTE_NOMATCH } from "../../../routes/routes";
import { useLocation } from "react-router-dom";

export const Breadcrumb = () => {
    const { pathname } = useLocation();
    return (
        <Container>
            <BootstrapBreadcrumb>
                <BootstrapBreadcrumb.Item href="https://www.dsv-gruppe.de">
                    Startseite ZIMDB
                </BootstrapBreadcrumb.Item>
                <LinkContainer exact to={ROUTE_INDEX}>
                    <BootstrapBreadcrumb.Item>
                        {
                            routes.find(route => route.path === ROUTE_INDEX)
                                ?.title
                        }
                    </BootstrapBreadcrumb.Item>
                </LinkContainer>
                <LinkContainer
                    exact
                    to={pathname === ROUTE_NOMATCH ? ROUTE_INDEX : pathname}
                >
                    <BootstrapBreadcrumb.Item active>
                        {routes.find(route => route.path === pathname)?.title ||
                            routes.find(route => route.path === ROUTE_NOMATCH)
                                ?.title}
                    </BootstrapBreadcrumb.Item>
                </LinkContainer>
            </BootstrapBreadcrumb>
        </Container>
    );
};

export default Breadcrumb;
