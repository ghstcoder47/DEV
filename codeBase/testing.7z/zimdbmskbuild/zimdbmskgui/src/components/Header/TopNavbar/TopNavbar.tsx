import React from "react";
import Navbar from "react-bootstrap/Navbar";
import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import logoType from "../../../images/logo-type.svg";

const TopNavbar = () => {
    return (
        <Navbar className="top-navbar" bg="light" expand="lg" sticky="top">
            <Container>
                <Navbar.Brand href="#home">
                    <img src={logoType} alt="Logo DSV-Gruppe" />
                </Navbar.Brand>
                <Nav className="mr-auto"></Nav>
                <Nav.Item>
                    <Nav.Link href="#link">
                        <span className="dsv-icon dsv-icon-chat-bubble" />
                    </Nav.Link>
                </Nav.Item>
                <Nav.Item>
                    <Nav.Link href="#link">
                        <span className="dsv-icon dsv-icon-logout" />
                    </Nav.Link>
                </Nav.Item>
            </Container>
        </Navbar>
    );
};

export default TopNavbar;
