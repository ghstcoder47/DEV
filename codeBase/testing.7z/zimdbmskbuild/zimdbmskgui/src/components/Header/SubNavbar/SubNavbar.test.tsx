import React from "react";
import { shallow } from "enzyme";
import { SubNavbar } from ".";
import Nav from "react-bootstrap/Nav";
import { useLocation } from "react-router-dom";
import {
    ROUTE_INDEX,
    ROUTE_ABFRAGEN,
    ROUTE_INFO
} from "../../../routes/routes";

jest.mock("react-router-dom", () => ({
    ...jest.requireActual("react-router-dom"),
    useLocation: jest.fn(() => {
        throw new Error("Mock behavior not defined.");
    })
}));

describe("SubNavbar component", () => {
    afterEach(() => {
        jest.clearAllMocks();
    });

    it("should render and contain no active nav items, given route '/' is active.", () => {
        (useLocation as jest.Mock).mockReturnValueOnce({
            pathname: ROUTE_INDEX
        });

        const wrapper = shallow(<SubNavbar />);
        const navItemWrapper = wrapper.find(Nav.Item);
        expect(navItemWrapper.at(0)).not.toHaveClassName("active");
        expect(navItemWrapper.at(1)).not.toHaveClassName("active");
        expect(
            navItemWrapper
                .at(0)
                .find(Nav.Link)
                .first()
        ).toHaveProp("active", false);
        expect(
            navItemWrapper
                .at(1)
                .find(Nav.Link)
                .first()
        ).toHaveProp("active", false);
        expect(useLocation).toHaveBeenCalledTimes(1);
        expect(wrapper).toMatchSnapshot();
    });

    it("should render and contain an active nav item '/abfragen', given route '/abfragen' is active.", () => {
        (useLocation as jest.Mock).mockReturnValueOnce({
            pathname: ROUTE_ABFRAGEN
        });

        const wrapper = shallow(<SubNavbar />);
        const navItemWrapper = wrapper.find(Nav.Item);
        expect(navItemWrapper.at(0)).toHaveClassName("active");
        expect(navItemWrapper.at(1)).not.toHaveClassName("active");
        expect(
            navItemWrapper
                .at(0)
                .find(Nav.Link)
                .first()
        ).toHaveProp("active", true);
        expect(
            navItemWrapper
                .at(1)
                .find(Nav.Link)
                .first()
        ).toHaveProp("active", false);
        expect(useLocation).toHaveBeenCalledTimes(1);
        expect(wrapper).toMatchSnapshot();
    });

    it("should render and contain an active nav item '/info', given route '/info' is active.", () => {
        (useLocation as jest.Mock).mockReturnValueOnce({
            pathname: ROUTE_INFO
        });

        const wrapper = shallow(<SubNavbar />);
        const navItemWrapper = wrapper.find(Nav.Item);
        expect(navItemWrapper.at(0)).not.toHaveClassName("active");
        expect(navItemWrapper.at(1)).toHaveClassName("active");
        expect(
            navItemWrapper
                .at(0)
                .find(Nav.Link)
                .first()
        ).toHaveProp("active", false);
        expect(
            navItemWrapper
                .at(1)
                .find(Nav.Link)
                .first()
        ).toHaveProp("active", true);
        expect(useLocation).toHaveBeenCalledTimes(1);
        expect(wrapper).toMatchSnapshot();
    });
});
