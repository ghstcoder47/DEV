import React from "react";
import Container from "react-bootstrap/Container";
import Navbar from "react-bootstrap/Navbar";
import Nav from "react-bootstrap/Nav";
import { useLocation } from "react-router-dom";
import { LinkContainer } from "react-router-bootstrap";
import {
    ROUTE_ABFRAGEN,
    ROUTE_INFO,
    ROUTE_INDEX
} from "../../../routes/routes";

const SubNavbar = () => {
    const { pathname } = useLocation();
    return (
        <Container>
            <Navbar className="sub-navbar" bg="light" expand="lg">
                <LinkContainer to={ROUTE_INDEX} exact>
                    <Navbar.Brand>MSK</Navbar.Brand>
                </LinkContainer>
                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                <Navbar.Collapse id="basic-navbar-nav">
                    <Nav className="mr-auto">
                        <Nav.Item
                            className={
                                pathname === ROUTE_ABFRAGEN ? "active" : ""
                            }
                        >
                            <LinkContainer to={ROUTE_ABFRAGEN} exact>
                                <Nav.Link active={pathname === ROUTE_ABFRAGEN}>
                                    Abfragen
                                </Nav.Link>
                            </LinkContainer>
                        </Nav.Item>
                        <Nav.Item
                            className={pathname === ROUTE_INFO ? "active" : ""}
                        >
                            <LinkContainer to={ROUTE_INFO} exact>
                                <Nav.Link active={pathname === ROUTE_INFO}>
                                    Info
                                </Nav.Link>
                            </LinkContainer>
                        </Nav.Item>
                    </Nav>
                </Navbar.Collapse>
            </Navbar>
        </Container>
    );
};

export default SubNavbar;
