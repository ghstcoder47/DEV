import React from "react";
import { TopNavbar } from "./TopNavbar";
import { SubNavbar } from "./SubNavbar";
import { Breadcrumb } from "./Breadcrumb";
import { useLocation } from "react-router-dom";
import { routes, ROUTE_NOMATCH } from "../../routes/routes";

const Header = () => {
    const { pathname } = useLocation();
    document.title =
        "MSK - " + routes.find(route => pathname === route.path)?.title ||
        routes.find(route => route.path === ROUTE_NOMATCH)?.title ||
        "";
    return (
        <>
            <TopNavbar />
            <SubNavbar />
            <Breadcrumb />
        </>
    );
};

export default Header;
