import React from "react";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import logo from "../../images/logo.svg";

const Footer = () => {
    return (
        <footer className="footer">
            <Container>
                <Row>
                    <Col md="9">
                        <p className="hidden-print">
                            <a href="#Kontakt">Kontakt</a> |{" "}
                            <a href="#Impressum">Impressum</a> |{" "}
                            <a href="#Datenschutz">Datenschutz</a>
                        </p>
                        <p className="small">
                            © Deutscher Sparkassen Verlag GmbH. Alle Rechte
                            vorbehalten. Vervielfältigung nur mit Genehmigung
                            der Deutscher Sparkassen Verlag GmbH.
                        </p>
                    </Col>
                    <Col md="3" className="hidden-print">
                        <p className="text-right">
                            <img
                                src={logo}
                                alt="Logo Deutscher Sparkassen Verlag GmbH"
                            />
                        </p>
                    </Col>
                </Row>
            </Container>
        </footer>
    );
};

export default Footer;
