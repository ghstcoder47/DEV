import React from "react";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import { Header } from "./components/Header";
import { Footer } from "./components/Footer";
import { routes } from "./routes/routes";

const App = () => {
    return (
        <>
            <Router>
                <Header />
                <Switch>
                    {routes.map((route, key) => (
                        <Route {...route} key={key} />
                    ))}
                </Switch>
                <Footer />
            </Router>
        </>
    );
};

export default App;
